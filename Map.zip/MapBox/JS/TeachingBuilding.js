export { Layer1_1 , Layer1_2 , Layer1_3};

const polygon1 = {
    'type': 'Feature',
    'geometry': {
        'type': 'Polygon',
        'coordinates': [[
            [113.99220, 22.59926],
            [113.99277, 22.59913],
            [113.99264, 22.59892],
            [113.99221, 22.59899],
            [113.99215, 22.59878],
            [113.99252, 22.59861],
            [113.99241, 22.59839],
            [113.99188, 22.59862],
            [113.99220, 22.59926] // 闭合多边形
        ]]
    }
};

// 添加一教的图层
const Layer1_1 = {
    'id': '1jiao',
    'type': 'fill-extrusion',
    'source': {
        'type': 'geojson',
        'data': polygon1
    },
    'paint': {
        'fill-extrusion-color': '#062f96',
        'fill-extrusion-height': 20,
        'fill-extrusion-base': 0,
        'fill-extrusion-opacity': 0.8
    }
};

// 1.2 二教
const polygon2 = {
    'type': 'Feature',
    'geometry': {
        'type': 'Polygon',
        'coordinates': [[
            [113.99164, 22.59770],
            [113.99212, 22.59768],
            [113.99208, 22.59729],
            [113.99161, 22.59733],
            [113.99164, 22.59770] // 闭合多边形
        ]]
    }
};

// 添加二教的图层
const Layer1_2 = {
    'id': '2jiao',
    'type': 'fill-extrusion',
    'source': {
        'type': 'geojson',
        'data': polygon2
    },
    'paint': {
        'fill-extrusion-color': '#062f96',
        'fill-extrusion-height': 20,
        'fill-extrusion-base': 0,
        'fill-extrusion-opacity': 0.8
    }
}

//1.3 三教
const polygon3 = {
    'type': 'Feature',
    'geometry': {
        'type': 'Polygon',
        'coordinates': [[
            [113.99501,22.59945],
            [113.99548,22.59916],
            [113.99494,22.59857],
            [113.99453,22.59888],
            [113.99501,22.59945] // 闭合多边形
        ]]
    }
};

// 添加二教的图层
const Layer1_3 = {
    'id': '3jiao',
    'type': 'fill-extrusion',
    'source': {
        'type': 'geojson',
        'data': polygon3
    },
    'paint': {
        'fill-extrusion-color': '#062f96',
        'fill-extrusion-height': 20,
        'fill-extrusion-base': 0,
        'fill-extrusion-opacity': 0.8
    }
}